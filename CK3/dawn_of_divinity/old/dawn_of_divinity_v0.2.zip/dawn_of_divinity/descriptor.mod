version="0.2"
name="Dawn of Divinity"
tags = {
	"Gameplay"
	"Utilities"
}
supported_version="1.20.*"
